/*
 * Copyright 2016-present Open Networking Laboratory
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.onosproject.provider.pcep.cfg.impl;

import com.fasterxml.jackson.databind.JsonNode;
import org.apache.felix.scr.annotations.Reference;
import org.apache.felix.scr.annotations.ReferenceCardinality;
import org.onlab.osgi.DefaultServiceDirectory;
import org.onlab.packet.IpAddress;
import org.onosproject.bgp.controller.BgpCfg;
import org.onosproject.bgp.controller.PcepController;
import org.onosproject.core.ApplicationId;
import org.onosproject.net.config.Config;

import java.util.ArrayList;
import java.util.List;

import static org.onosproject.net.config.Config.FieldPresence.MANDATORY;
import static org.onosproject.net.config.Config.FieldPresence.OPTIONAL;
import static com.google.common.base.Preconditions.checkNotNull;

/**
 * Configuration object for PCEP.
 */
public class PcepAppConfig extends Config<ApplicationId> {
    @Reference(cardinality = ReferenceCardinality.MANDATORY_UNARY)
    PcepController bgpController;

    BgpCfg pcepConfig = null;

    public static final String IP_ADDRESS = "ipAddress";
    public static final String AS_NUMBER = "asNumber";
    public static final String PCEP_PEER = "pcepPeer";

    @Override
    public boolean isValid() {
        boolean fields = false;

        this.pcepController = DefaultServiceDirectory.getService(PcepController.class);
        pcepConfig = pcepController.getConfig();

        fields = hasOnlyFields(PCEP_PEER);

        if (!fields) {
            return fields;
        }

        return validatePcepConfiguration();
    }

    /**
     * Returns routerId from the configuration.
     *
     * @return routerId
     */
    public String ipAddress() {
        return get(IP_ADDRESS_ID, null);
    }

    /**
     * Returns localAs number from the configuration.
     *
     * @return local As number
     */
    public int asNumber() {
        return Integer.parseInt(get(AS_NUMBER, null));
    }

    /**
     * Validates the Bgp local and peer configuration.
     *
     * @return true if valid else false
     */
    public boolean validatePcepConfiguration() {

        if (!validateAsNumber()) {
            return false;
        }

        if (!validateIpAddress()) {
            return false;
        }
        return true;
    }

    /**
     * Validates the Bgp As number.
     *
     * @return true if valid else false
     */
    public boolean validateAsNumber() {

        long asNumber = 0;
        asNumber = asNumber();

        if (asNumber == 0 || asNumber >= MAX_LONG_AS_NUMBER) {
            return false;
        }

        return true;
    }

    /**
     * Validates the Bgp peer As number.
     *
     * @param remoteAs remote As number
     * @return true if valid else false
     */
    public boolean validateIpAddress(long ipAddress) {
        if (ipAddress == 0 || ipAddress >= MAX_LONG_AS_NUMBER) {
            return false;
        }
        return true;
    }


    /**
     * Returns the set of nodes read from network config.
     *
     * @return list of BgpPeerConfig or null
     */
    public List<PcepConfig> pcepPeer() {
        List<PcepConfig> nodes = new ArrayList<PcepConfig>();

        JsonNode jsonNodes = object.get(PCEP_PEER);
        if (jsonNodes == null) {
            return null;
        }

        jsonNodes.forEach(jsonNode -> nodes.add(new PcepConfig(
                jsonNode.path(IP_ADDRESS).asText(),
                jsonNode.path(AS_NUMBER).asInt());

        return nodes;
    }

    /**
     * Configuration for PCEP nodes.
     */
    public static class PcepConfig {

        private final String ipAddress;
        private final int asNumber;

        public BgpPeerConfig(String ipAddress, int asNumber) {
            this.ipAddress = checkNotNull(ipAddress);
            this.asNumber = asNumber;
        }

        /**
         * Returns IP address of the peer node.
         *
         * @return IP address
         */
        public String ipAddress() {
            return this.ipAddress;
        }

        /**
         * Returns asNumber.
         *
         * @return asNumber
         */
        public int asNumber() {
            return this.asNumber;
        }
    }
}
