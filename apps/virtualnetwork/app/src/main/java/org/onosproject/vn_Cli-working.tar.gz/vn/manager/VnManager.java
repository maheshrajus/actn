/*
 * Copyright 2016-present Open Networking Laboratory
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.onosproject.vn.manager;

import org.apache.felix.scr.annotations.Activate;
import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Deactivate;
import org.apache.felix.scr.annotations.Reference;
import org.apache.felix.scr.annotations.ReferenceCardinality;
import org.apache.felix.scr.annotations.Service;
import org.onlab.util.Bandwidth;
import org.onosproject.core.ApplicationId;
import org.onosproject.core.CoreService;
import org.onosproject.incubator.net.tunnel.TunnelId;
import org.onosproject.net.intent.Constraint;
import org.onosproject.pce.pceservice.LspType;
import org.onosproject.pce.pceservice.api.PceService;
import org.onosproject.pce.pceservice.constraint.CostConstraint;
import org.onosproject.pce.pceservice.constraint.SharedBandwidthConstraint;
import org.onosproject.vn.manager.api.VnService;
import org.onosproject.vn.manager.constraint.VnBandwidth;
import org.onosproject.vn.manager.constraint.VnConstraintType;
import org.onosproject.vn.manager.constraint.VnCost;
import org.onosproject.vn.store.EndPoint;
import org.onosproject.vn.store.Lsp;
import org.onosproject.vn.store.VirtualNetwork;
import org.onosproject.vn.store.api.VnStore;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.LinkedList;
import java.util.List;
import java.util.Map;

/**
 * Implementation of virtual network service.
 */
@Component(immediate = true)
@Service
public class VnManager implements VnService {
    private static final Logger log = LoggerFactory.getLogger(VnManager.class);

    public static final String VN_SERVICE_APP = "org.onosproject.vn";
    private ApplicationId appId;

    @Reference(cardinality = ReferenceCardinality.MANDATORY_UNARY)
    protected CoreService coreService;

    @Reference(cardinality = ReferenceCardinality.MANDATORY_UNARY)
    protected VnStore vnStore;

    @Reference(cardinality = ReferenceCardinality.MANDATORY_UNARY)
    protected PceService service;

    /**
     * Creates new instance of vnManager.
     */
    public VnManager() {
    }

    @Activate
    protected void activate() {
        appId = coreService.registerApplication(VN_SERVICE_APP);
        log.info("Started");
    }

    @Deactivate
    protected void deactivate() {
        log.info("Stopped");
    }


    @Override
    public boolean setupVn(String vnName, List<VnConstraintType> constraints, EndPoint endPoint) {
        //TODO:
        if (!vnStore.setupVn(vnName, constraints, endPoint)) {
            return false;
        }

        VirtualNetwork virtualNetwork = vnStore.queryVn(vnName);
        for (Lsp lsp : virtualNetwork.lsp()) {
            String tunnelName = lsp.src().toString().concat(lsp.dst().toString());
            //service.setupPath(lsp.src(), lsp.dst(), tunnelName, getConstraints(constraints), LspType.WITH_SIGNALLING);
        }
        return true;
    }

    @Override
    public boolean setupVn(String vnName, EndPoint endPoint) {
        if (!vnStore.setupVn(vnName, endPoint)) {
            return false;
        }
        VirtualNetwork virtualNetwork = vnStore.queryVn(vnName);
        for (Lsp lsp : virtualNetwork.lsp()) {
            String tunnelName = lsp.src().toString().concat(lsp.dst().toString());
            service.setupPath(lsp.src(), lsp.dst(), tunnelName, null, LspType.WITH_SIGNALLING);
        }
        return true;
    }

    @Override
    public boolean updateVn(String vnName, EndPoint endPoint) {
        if (!vnStore.updateVn(vnName, endPoint)) {
            return false;
        }
        VirtualNetwork virtualNetwork = vnStore.queryVn(vnName);
        for (Lsp lsp : virtualNetwork.lsp()) {
            String tunnelName = lsp.src().toString().concat(lsp.dst().toString());

            //TODO: currently no interface for updatePath in pceService
            service.setupPath(lsp.src(), lsp.dst(), tunnelName, null, LspType.WITH_SIGNALLING);
        }
        return true;
    }

    List<Constraint> getConstraints(List<VnConstraintType> constraint) {
        List<Constraint> pceConstraint = new LinkedList<>();
        for (VnConstraintType c : constraint) {
            if (c.getType() == VnBandwidth.TYPE) {
                VnBandwidth vnBandwidth = (VnBandwidth) c;
                SharedBandwidthConstraint bandWidth = SharedBandwidthConstraint.of(null, Bandwidth.bps(100),
                                                                                   vnBandwidth.bandWidthValue());
                pceConstraint.add(bandWidth);
            } else if (c.getType() == VnCost.TYPE) {
                VnCost vnCost = (VnCost) c;
                int cost = vnCost.type().type();
                CostConstraint.Type type = CostConstraint.Type.COST;
                if (cost == 1) {
                    type = CostConstraint.Type.COST;
                } else if (cost == 2) {
                    type = CostConstraint.Type.TE_COST;
                }
                CostConstraint costConstraint = new CostConstraint(type);
                pceConstraint.add(costConstraint);
            }
        }
        return pceConstraint;
    }

    @Override
    public boolean updateVn(String vnName, List<VnConstraintType> constraint) {
       if (!vnStore.updateVn(vnName, constraint)) {
           return false;
       }


       VirtualNetwork virtualNetwork = vnStore.queryVn(vnName);
       for (Lsp lsp : virtualNetwork.lsp()) {
           String tunnelName = lsp.src().toString().concat(lsp.dst().toString());
           service.updatePath(TunnelId.valueOf(tunnelName), getConstraints(constraint));
       }
       return true;
    }

    @Override
    public boolean deleteVn(String vnName) {
        if (!vnStore.deleteVn(vnName)) {
            return false;
        }
        VirtualNetwork virtualNetwork = vnStore.queryVn(vnName);
        for (Lsp lsp : virtualNetwork.lsp()) {
            String tunnelName = lsp.src().toString().concat(lsp.dst().toString());
            service.releasePath(TunnelId.valueOf(tunnelName));
        }
        return true;
    }

    @Override
    public VirtualNetwork queryVn(String vnName) {
        return vnStore.queryVn(vnName);
    }

    @Override
    public List<VirtualNetwork> queryAllVn() {
        Map<String, VirtualNetwork> vnMap = vnStore.queryAllVn();
        List<VirtualNetwork> vn = new LinkedList<>();
        for (String vnName : vnMap.keySet()) {
            vn.add(vnStore.queryVn(vnName));
        }
        return vn;
    }
}
